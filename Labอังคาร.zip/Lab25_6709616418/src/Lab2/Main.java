package Lab2;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
			Queue queue = new Queue();
			queue.enqueue(1);
			queue.enqueue(2);
			queue.enqueue(3);
			queue.enqueue(4);
			queue.enqueue(5);
			queue.enqueue(6);
			
			int head = queue.dequeue() ;
				System.out.println("Head element of queue when dequeue:" + head) ;
				System.out.println("The number of Elements in queue:" + queue.count()) ;
				System.out.println("2 is in queue?=>" +queue.hasElement(2));
				System.out.println("10 is in queue?=>" +queue.hasElement(10));
				head = queue.dequeue() ;
				
				System.out.println("Head element of queue when dequeue:" + head) ;
				System.out.println("The number of Elements in queue:" + queue.count()) ;
				System.out.println("2 is in queue?=>" +queue.hasElement(2));
				System.out.println("3 is in queue?=>" +queue.hasElement(3));
				queue.displayElements();
			//end-of-main-method
			//end-of-Main-class
			// ออกแบบ Array 1 มิติให้เก็บ int สมาชิกของ queue
	}
}