package Lab2;

public class Queue {
	private int[] elements;
	
	//Default Constructor
	public Queue() {
		//เอาไว้new array จะได้ใช้งานได้
		elements = new int[6];
	}
	
	//enqueue(int);
	public void enqueue(int x) {
		
	}
	
	//dequeue(int);
	public int dequeue() {
		
	}
	
	//hasElement(int):boolean
	public boolean hasElement(int x) {
		
	}
	
	//count():int
	public int count() {
		
	}
	
	//displayElements();
	public void displayElements() {
		System.out.println();
	}
}