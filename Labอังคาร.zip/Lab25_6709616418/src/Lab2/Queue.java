package Lab2;
import java.util.Scanner;

public class Queue {
	private int[] elements= {1,2,3,4,5,6};
	
	//Default Constructor
	public Queue() {
		
	}
	
	//enqueue(int);
	public void enqueue(int x) {
		
	}
	
	//dequeue(int);
	public int dequeue() {
		
	}
	
	//hasElement(int):boolean
	public boolean hasElement(int x) {
		
	}
	
	//count():int
	public int count() {
		
	}
	
	//displayElements();
	public void displayElements() {
		System.out.println();
	}
}