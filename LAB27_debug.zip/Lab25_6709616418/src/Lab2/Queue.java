package Lab2;

public class Queue {
	private int[] elements;
	private int count;
	
	//Default Constructor
	public Queue() {
		//เอาไว้new array จะได้ใช้งานได้
		//new Queue then new array with the capacity of 5
		elements = new int[5];
		count=0; 
	}
	
	//enqueue(int);
	public void enqueue(int x) {
		//check whether queue is full 
		//if not, add x to array at the index count
		//and increment count
		
		//กรณีไม่เต็ม
		if (count < elements.length ) {
			elements[count] = x;
			count++;
		}
		else {
			//if queue is full, expand array to double size 
			//create new array double size of the existing array
			int[] expandedArr = new int[elements.length*2]; 
			//copy elements from the existing array to the expanded array
			for (int i=0; i<elements.length ;i++) {
				expandedArr[i] = elements[i];
			}
			
			// หริอ int[] expandedArr = new int[elements.length*2];  
			//int[] expandedArr = (int[])elements.clone();
			
			//add x to expanded array
			expandedArr[count] = x;
			count++;
			elements = expandedArr;
		}
	}
	
	
	//dequeue(int);
	public int dequeue() {
		if (count>0) {
			int head = elements[0];
			for (int i=0; i<elements.length-1;i++) {
				elements[i]=elements[i+1];
			}
			count--;
			return head;
		}
		else {
			return -1;
			// exception code
		}
	}
	
	//hasElement(int):boolean
	public boolean hasElement(int x) {
		int i=0;
		boolean found = false;
		while (i<count) {
			if (elements[i]==x) {
				found = true;
				break;
			}
			i++;
		}
		return found;
	}
	
	//count():int
	public int count() {
		return count;
	}
	
	//displayElements();
	public void displayElements() {
		if(count>0) {
			for(int num: elements) {
				System.out.printf("|%d| ", num);
			}
		System.out.println("");
		}
		else {
			System.out.println("Empty Queue.");
		}
	}
	
}